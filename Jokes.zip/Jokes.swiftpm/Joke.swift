import SwiftUI

struct Joke {
    var setup : String
    var punchline: String
}
