import SwiftUI

struct ContentView: View {
    
    @State private var counter = 0
    
    var body: some View {
        VStack {
            Text("\(counter) Cookies")
            Button("I ATE ANOTHER ONE!!") {
                counter = counter + 1
                print(counter)
            }
            
            if counter > 0 {
                Button("A COOKIE FELL OUT OF MY MOUTH!!") {
                    counter = counter - 1
                    print(counter)
                }                
            }
        }
    }
}
