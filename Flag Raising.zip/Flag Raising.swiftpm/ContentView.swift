import SwiftUI

struct ContentView: View {
    
    @State var counter = 0
    @State var message = ""
    
    var body: some View {
        VStack {
            Text("\(counter)")
            
            HStack(alignment: .bottom, spacing: -10) {
                Rectangle()
                    .frame(width: 20)
                
                Text("🇸🇬")
                    .font(.system(size: 100))
                    .offset(y: -10 * CGFloat(counter))
            }
            
            Button {
                print("Raise Flag!!")
                
                withAnimation {
                    counter += 1
                    
                    if counter >= 40 {
                        message = "See this island"
                    } else if counter >= 30 {
                        message = "Every grain of sand"
                    } else {
                        message = "Hear this anthem"
                    }
                }
            } label: {
                Text("Raise Flag")
                    .padding()
                    .background(.blue)
                    .foregroundColor(.white)
            }
            
            if counter >= 20 {
                Text(message)
            }
        }
    }
}
