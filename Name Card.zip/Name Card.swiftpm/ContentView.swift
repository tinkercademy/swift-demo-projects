import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Color.red
            HStack(alignment: .top) {
                Image("MyImage")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                    .clipShape(Circle())
                VStack {
                    Text("YJ Soon")
                        .bold()
                        .italic()
                        .font(.system(size: 40))
                        .padding()
                        .foregroundStyle(.green)
                        .background(.blue)
                    Text("Swift Instructor")
                        .font(.system(size: 20))
                    HStack {
                        Link(destination: URL(string: "mailto:hello@tk.sg")!) {
                            Image(systemName: "mail")
                        }
                        Link(destination: URL(string: "https://tk.sg/importantLink")!) {
                            Image(systemName: "pc")
                        }
                    }
                    .font(.system(size: 20))
                    .foregroundStyle(.yellow)
                    .padding(.top)
                }
            }
        }
    }
}
